# Cinema Pro Player

Advanced Android video player — ExoPlayer (Media3), 15-band cinema DSP audio engine
(bass boost, virtualizer, surround/Atmos-style modes, night mode, dialog enhancement),
AI upscaling hooks (TFLite, gracefully falls back if model assets aren't bundled),
foreground playback service + media session, Room-backed preset storage, Jetpack Compose UI.

## Build via GitHub Actions
Push this repo to GitHub — `.github/workflows/build.yml` auto-builds debug + unsigned
release APKs on every push and uploads them as workflow artifacts (Actions tab → run → Artifacts).
No local Android Studio or gradlew jar needed; the workflow provisions Gradle itself.

## Notes
- minSdk 26, targetSdk/compileSdk 34
- AI upscale (`AIUpscaleEngine`) expects optional `.tflite` models in `app/src/main/assets/`
  (`esrgan_4x.tflite`, `esrgan_8x.tflite`, etc.) — if absent, it logs a warning and skips
  AI upscaling rather than crashing.
- Launcher icon is a vector adaptive icon (no PNG assets needed).
