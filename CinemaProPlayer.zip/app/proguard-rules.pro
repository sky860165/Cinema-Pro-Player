# ProGuard rules for Cinema Pro Player
-keep class com.cinemapro.player.** { *; }
-keepclassmembers class com.cinemapro.player.** { *; }

# TensorFlow Lite
-keep class org.tensorflow.lite.** { *; }
-keep class org.tensorflow.lite.gpu.** { *; }

# Media3
-keep class androidx.media3.** { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
