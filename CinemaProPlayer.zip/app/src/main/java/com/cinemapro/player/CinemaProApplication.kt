package com.cinemapro.player

import android.app.Application
import androidx.room.Room
import com.cinemapro.player.data.database.CinemaProDatabase

class CinemaProApplication : Application() {

    lateinit var database: CinemaProDatabase
        private set

    companion object {
        lateinit var instance: CinemaProApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = Room.databaseBuilder(
            applicationContext,
            CinemaProDatabase::class.java,
            "cinema_pro_database"
        ).build()
    }
}
