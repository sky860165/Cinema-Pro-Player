package com.cinemapro.player

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.cinemapro.player.ui.screens.VideoGalleryScreen
import com.cinemapro.player.ui.theme.CinemaProTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Resume the global equalizer service if the user had it on before
        // (e.g. after the app process was killed by the system).
        if (com.cinemapro.player.service.GlobalEqualizerService.isEnabled(this)) {
            val svcIntent = android.content.Intent(this, com.cinemapro.player.service.GlobalEqualizerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svcIntent)
            } else {
                startService(svcIntent)
            }
        }

        // If launched from file manager with a video URI, go directly to player.
        //
        // IMPORTANT: PlaybackUriResolver.resolve() can copy the whole video
        // file (potentially several GB) — that must NEVER run on the main
        // thread, or it blocks the UI and triggers "App Not Responding"
        // (exactly what was happening here). So: play immediately off the
        // original intent URI (2D playback works fine on that), and resolve
        // the safe-to-reopen local copy on a background thread. Once ready,
        // we swap videoUri via Compose state — CinemaProPlayerScreen picks
        // up the new value automatically (it's keyed on videoUri already
        // for its effects-reload LaunchedEffect) and later switches to
        // 3D/4K mode will use the resolved local file instead of the
        // original content:// uri.
        val originalUri = intent?.data
        var resolvedUriState by mutableStateOf(originalUri?.toString())

        if (originalUri?.scheme == "content") {
            MainScope().launch {
                val resolved = withContext(Dispatchers.IO) {
                    com.cinemapro.player.util.PlaybackUriResolver.resolve(this@MainActivity, originalUri)
                }
                resolvedUriState = resolved?.toString() ?: originalUri.toString()
            }
        }

        setContent {
            val videoUri = resolvedUriState
            CinemaProTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (videoUri != null) {
                        // Direct play from external intent
                        com.cinemapro.player.ui.screens.CinemaProPlayerScreen(
                            videoUri = videoUri,
                            videoTitle = videoUri.substringAfterLast("/"),
                            onBackPressed = { finish() }
                        )
                    } else {
                        // Show video gallery/browser
                        VideoGalleryScreen(
                            onVideoSelected = { video ->
                                // Navigate to player with selected video
                                val intent = android.content.Intent(this, PlayerActivity::class.java).apply {
                                    data = video.uri
                                    putExtra("VIDEO_TITLE", video.title)
                                    putExtra("VIDEO_ID", video.id)
                                }
                                startActivity(intent)
                            }
                        )
                    }
                }
            }
        }
    }
}
