package com.cinemapro.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.cinemapro.player.ui.screens.CinemaProPlayerScreen
import com.cinemapro.player.ui.theme.CinemaProTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val videoUri = intent?.data?.toString()
            ?: "content://media/external/video/media/1"

        setContent {
            CinemaProTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CinemaProPlayerScreen(
                        videoUri = videoUri,
                        onBackPressed = { finish() }
                    )
                }
            }
        }
    }
}
