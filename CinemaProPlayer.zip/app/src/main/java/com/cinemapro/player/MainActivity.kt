package com.cinemapro.player

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.cinemapro.player.ui.screens.VideoGalleryScreen
import com.cinemapro.player.ui.theme.CinemaProTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Resume the global equalizer service if the user had it on before
        // (e.g. after the app process was killed by the system).
        if (com.cinemapro.player.service.GlobalEqualizerService.isEnabled(this)) {
            val svcIntent = android.content.Intent(this, com.cinemapro.player.service.GlobalEqualizerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svcIntent)
            } else {
                startService(svcIntent)
            }
        }

        // If launched from file manager with a video URI, go directly to player
        val videoUri = intent?.data?.toString()

        setContent {
            CinemaProTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (videoUri != null) {
                        // Direct play from external intent
                        com.cinemapro.player.ui.screens.CinemaProPlayerScreen(
                            videoUri = videoUri,
                            videoTitle = videoUri.substringAfterLast("/"),
                            onBackPressed = { finish() }
                        )
                    } else {
                        // Show video gallery/browser
                        VideoGalleryScreen(
                            onVideoSelected = { video ->
                                // Navigate to player with selected video
                                val intent = android.content.Intent(this, PlayerActivity::class.java).apply {
                                    data = video.uri
                                    putExtra("VIDEO_TITLE", video.title)
                                    putExtra("VIDEO_ID", video.id)
                                }
                                startActivity(intent)
                            }
                        )
                    }
                }
            }
        }
    }
}
