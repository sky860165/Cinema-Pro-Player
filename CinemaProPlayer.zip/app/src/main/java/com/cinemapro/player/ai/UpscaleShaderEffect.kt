package com.cinemapro.player.ai

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import com.cinemapro.player.data.model.UpscaleMode
import com.cinemapro.player.data.model.VideoMode3D

/* ============================================================================
 * WHY THIS APPROACH (read before changing the shaders)
 * ============================================================================
 * "AI 4K/8K upscale" that runs on a phone GPU in real time, every frame, at
 * 24-60fps, is NOT a neural network (ESRGAN/Real-ESRGAN-class models run at
 * roughly 1-5fps for a 4x upscale even on a flagship phone GPU — far too
 * slow for watching a movie smoothly). What real real-time GPU upscalers do
 * (AMD FSR 1.0, Nvidia Image Scaling, and what TVs call "AI upscale" in
 * marketing) is: sharper resampling + edge-aware sharpening + local-contrast
 * enhancement, entirely in a fragment shader, costing a fraction of a
 * millisecond per frame. That's exactly what UpscaleGlShaderProgram below
 * does — it is real, it runs on the GPU every frame, and it visibly sharpens
 * detail without melting your phone's battery or dropping frames.
 *
 * "Real 3D" (SBS / TAB) below is genuinely real: it reads the *single*
 * decoded movie frame and renders it twice, each half cropped/positioned
 * correctly into the left and right halves (SBS) or top and bottom halves
 * (TAB) of the output frame — the standard format 3D TVs and VR headsets
 * expect when you select "Side-by-Side" or "Top-Bottom" input mode. This is
 * for converting a normal 2D video into the SBS/TAB *container format* (duplicate
 * view in each half) — it does not magically invent stereo depth from a 2D
 * source (no software can do that in real time without a depth model, which
 * has the same speed problem as AI upscale above). If your video file is
 * *already* a real 3D SBS/TAB source, selecting these modes here would
 * incorrectly double it — only use them to package ordinary 2D video for a
 * 3D-capable display/headset.
 * ========================================================================= */

@UnstableApi
class UpscaleGlEffect(private val mode: UpscaleMode) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): androidx.media3.effect.GlShaderProgram {
        return when (mode) {
            UpscaleMode.DENOISE -> DenoiseGlShaderProgram(context, useHdr)
            UpscaleMode.HDR_SIMULATION -> HdrSimGlShaderProgram(context, useHdr)
            else -> UpscaleGlShaderProgram(context, mode, useHdr)
        }
    }
}

@UnstableApi
private class UpscaleGlShaderProgram(
    context: Context,
    mode: UpscaleMode,
    useHdr: Boolean
) : BaseGlShaderProgram(useHdr, /* texturePoolCapacity= */ 1) {

    private val glProgram = GlProgram(context, VERTEX_SHADER, fragmentShaderFor(mode))
    private val sharpenAmount = strengthFor(mode)
    private var frameWidth = 1
    private var frameHeight = 1

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        frameWidth = inputWidth
        frameHeight = inputHeight
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.setFloatUniform("uTexelWidth", 1f / frameWidth.coerceAtLeast(1))
            glProgram.setFloatUniform("uTexelHeight", 1f / frameHeight.coerceAtLeast(1))
            glProgram.setFloatUniform("uSharpenAmount", sharpenAmount)
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            // already torn down, nothing else to do
        }
    }

    companion object {
        private fun strengthFor(mode: UpscaleMode): Float = when (mode) {
            UpscaleMode.AI_4K -> 0.55f
            UpscaleMode.AI_8K -> 0.85f
            UpscaleMode.SUPER_RESOLUTION -> 0.65f
            UpscaleMode.SHARPEN -> 0.7f
            else -> 0f
        }

        private const val VERTEX_SHADER = """
            attribute vec4 aFramePosition;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = aFramePosition;
                vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
            }
        """

        private fun fragmentShaderFor(mode: UpscaleMode): String {
            val extraContrast = mode == UpscaleMode.AI_8K
            return """
                precision mediump float;
                uniform sampler2D uTexSampler;
                uniform float uTexelWidth;
                uniform float uTexelHeight;
                uniform float uSharpenAmount;
                varying vec2 vTexSamplingCoord;

                vec3 sampleAt(float dx, float dy) {
                    return texture2D(uTexSampler, vTexSamplingCoord + vec2(dx * uTexelWidth, dy * uTexelHeight)).rgb;
                }

                void main() {
                    vec3 center = sampleAt(0.0, 0.0);

                    vec3 n  = sampleAt(0.0, -1.0);
                    vec3 s  = sampleAt(0.0,  1.0);
                    vec3 e  = sampleAt(1.0,  0.0);
                    vec3 w  = sampleAt(-1.0, 0.0);
                    vec3 ne = sampleAt(1.0, -1.0);
                    vec3 nw = sampleAt(-1.0, -1.0);
                    vec3 se = sampleAt(1.0,  1.0);
                    vec3 sw = sampleAt(-1.0, 1.0);

                    vec3 neighborAvg = (n + s + e + w + ne + nw + se + sw) / 8.0;
                    vec3 highPass = center - neighborAvg;

                    vec3 variance = abs(n - center) + abs(s - center) + abs(e - center) + abs(w - center);
                    float edgeStrength = clamp(dot(variance, vec3(0.333)) * 4.0, 0.0, 1.0);

                    vec3 sharpened = center + highPass * uSharpenAmount * edgeStrength;

                    ${if (extraContrast) """
                    vec3 contrastBoost = (sharpened - neighborAvg) * 0.25;
                    sharpened += contrastBoost * edgeStrength;
                    """ else ""}

                    gl_FragColor = vec4(clamp(sharpened, 0.0, 1.0), 1.0);
                }
            """
        }
    }
}

/**
 * Real-time edge-preserving smoothing ("denoise"). A true bilateral filter
 * needs many samples to be accurate; this uses a 3x3 weighted average where
 * weight falls off with color difference (cheap edge-preserving blur) — runs
 * every frame on the GPU at full speed and visibly reduces compression
 * blockiness/grain without turning the whole image to mush.
 */
@UnstableApi
private class DenoiseGlShaderProgram(
    context: Context,
    useHdr: Boolean
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram = GlProgram(context, VERTEX_SHADER, FRAGMENT_SHADER)
    private var frameWidth = 1
    private var frameHeight = 1

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        frameWidth = inputWidth
        frameHeight = inputHeight
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.setFloatUniform("uTexelWidth", 1f / frameWidth.coerceAtLeast(1))
            glProgram.setFloatUniform("uTexelHeight", 1f / frameHeight.coerceAtLeast(1))
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try { glProgram.delete() } catch (e: GlUtil.GlException) { }
    }

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aFramePosition;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = aFramePosition;
                vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTexSampler;
            uniform float uTexelWidth;
            uniform float uTexelHeight;
            varying vec2 vTexSamplingCoord;

            vec3 sampleAt(float dx, float dy) {
                return texture2D(uTexSampler, vTexSamplingCoord + vec2(dx * uTexelWidth, dy * uTexelHeight)).rgb;
            }

            void main() {
                vec3 center = sampleAt(0.0, 0.0);
                vec3 samples[8];
                samples[0] = sampleAt(-1.0, -1.0);
                samples[1] = sampleAt( 0.0, -1.0);
                samples[2] = sampleAt( 1.0, -1.0);
                samples[3] = sampleAt(-1.0,  0.0);
                samples[4] = sampleAt( 1.0,  0.0);
                samples[5] = sampleAt(-1.0,  1.0);
                samples[6] = sampleAt( 0.0,  1.0);
                samples[7] = sampleAt( 1.0,  1.0);

                vec3 sum = center;
                float weightSum = 1.0;
                const float sigma = 0.12;

                for (int i = 0; i < 8; i++) {
                    float diff = distance(samples[i], center);
                    float weight = exp(-(diff * diff) / (2.0 * sigma * sigma));
                    sum += samples[i] * weight;
                    weightSum += weight;
                }

                gl_FragColor = vec4(sum / weightSum, 1.0);
            }
        """
    }
}

/**
 * HDR Simulation tone mapping: gamma lift + local-contrast-aware saturation
 * boost, the same math the previous CPU bitmap version did, just running on
 * the GPU per-frame instead of as a one-off bitmap filter.
 */
@UnstableApi
private class HdrSimGlShaderProgram(
    context: Context,
    useHdr: Boolean
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram = GlProgram(context, VERTEX_SHADER, FRAGMENT_SHADER)

    override fun configure(inputWidth: Int, inputHeight: Int): Size = Size(inputWidth, inputHeight)

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try { glProgram.delete() } catch (e: GlUtil.GlException) { }
    }

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aFramePosition;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = aFramePosition;
                vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTexSampler;
            varying vec2 vTexSamplingCoord;

            void main() {
                vec3 color = texture2D(uTexSampler, vTexSamplingCoord).rgb;

                vec3 toneMapped = pow(color, vec3(0.8));

                float avg = (toneMapped.r + toneMapped.g + toneMapped.b) / 3.0;
                vec3 saturated = avg + (toneMapped - vec3(avg)) * 1.2;

                gl_FragColor = vec4(clamp(saturated, 0.0, 1.0), 1.0);
            }
        """
    }
}
/**
 * Real 3D rendering effects: SBS / TAB / Stereoscopic packaging, and real
 * Anaglyph (red-cyan channel separation).
 *
 * SBS/TAB/STEREOSCOPIC: renders the same decoded frame twice into the two
 * halves of the output — the real container format 3D displays and VR
 * headsets expect. STEREOSCOPIC here is the same dual-view packaging as SBS
 * (the two terms are used interchangeably by many 3D video players); it's
 * offered as a separate menu entry because some 3D TVs label their
 * "Side-by-Side" input differently from their generic "Stereoscopic" input,
 * even though the frame format you need to produce is identical.
 *
 * ANAGLYPH: genuinely separates the frame into red and cyan channels with a
 * small horizontal offset between them, exactly what red-cyan 3D glasses
 * are built to decode — your left eye (behind the red filter) sees mostly
 * the cyan-suppressed channel and vice versa, producing real depth-from-
 * offset when you wear the glasses, not just a tinted overlay.
 */
@UnstableApi
class Stereo3DGlEffect(private val mode: VideoMode3D) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): androidx.media3.effect.GlShaderProgram {
        return if (mode == VideoMode3D.ANAGLYPH) {
            AnaglyphGlShaderProgram(context, useHdr)
        } else {
            Stereo3DGlShaderProgram(context, mode, useHdr)
        }
    }
}

@UnstableApi
private class Stereo3DGlShaderProgram(
    context: Context,
    private val mode: VideoMode3D,
    useHdr: Boolean
) : BaseGlShaderProgram(useHdr, /* texturePoolCapacity= */ 1) {

    private val glProgram = GlProgram(context, VERTEX_SHADER, FRAGMENT_SHADER)

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        // Output buffer is the same resolution as input; the two views are
        // squeezed into the two halves (this matches how real SBS/TAB 3D
        // files are encoded — each eye gets a horizontally or vertically
        // squeezed half-frame, which the 3D display/headset un-squeezes).
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            // TAB = 1, everything else (SBS, STEREOSCOPIC) = 0 (left/right halves)
            glProgram.setIntUniform("uLayoutMode", if (mode == VideoMode3D.TAB) 1 else 0)
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
        }
    }

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aFramePosition;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = aFramePosition;
                vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
            }
        """

        // uLayoutMode: 0 = Side-by-Side (left/right halves), 1 = Top-and-Bottom
        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTexSampler;
            uniform int uLayoutMode;
            varying vec2 vTexSamplingCoord;

            void main() {
                vec2 uv = vTexSamplingCoord;
                vec2 sourceUv;

                if (uLayoutMode == 0) {
                    // Side-by-Side: left half of output -> full frame squeezed in,
                    // right half of output -> same full frame squeezed in again.
                    if (uv.x < 0.5) {
                        sourceUv = vec2(uv.x * 2.0, uv.y);
                    } else {
                        sourceUv = vec2((uv.x - 0.5) * 2.0, uv.y);
                    }
                } else {
                    // Top-and-Bottom: top half -> full frame, bottom half -> full frame.
                    if (uv.y < 0.5) {
                        sourceUv = vec2(uv.x, uv.y * 2.0);
                    } else {
                        sourceUv = vec2(uv.x, (uv.y - 0.5) * 2.0);
                    }
                }

                gl_FragColor = texture2D(uTexSampler, sourceUv);
            }
        """
    }
}

/**
 * Real red-cyan Anaglyph 3D. Since the source is a single 2D frame (no
 * actual second eye view exists), we manufacture the stereo offset the same
 * way classic 2D-to-anaglyph converters do: shift the channel sampling
 * slightly horizontally based on luminance (brighter/closer-looking areas
 * shift more), which produces a real, glasses-decodable depth cue rather
 * than just tinting the image red and cyan with no actual separation.
 */
@UnstableApi
private class AnaglyphGlShaderProgram(
    context: Context,
    useHdr: Boolean
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram = GlProgram(context, VERTEX_SHADER, FRAGMENT_SHADER)
    private var frameWidth = 1

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        frameWidth = inputWidth
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.setFloatUniform("uTexelWidth", 1f / frameWidth.coerceAtLeast(1))
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try { glProgram.delete() } catch (e: GlUtil.GlException) { }
    }

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aFramePosition;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = aFramePosition;
                vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTexSampler;
            uniform float uTexelWidth;
            varying vec2 vTexSamplingCoord;

            void main() {
                // Sample the center pixel's luminance to drive a small
                // pseudo-depth shift: brighter areas (often closer/more
                // prominent subjects in typical footage) get shifted more,
                // giving the red and cyan channels genuinely different
                // sampling positions instead of being perfectly aligned.
                vec3 centerColor = texture2D(uTexSampler, vTexSamplingCoord).rgb;
                float luminance = dot(centerColor, vec3(0.299, 0.587, 0.114));
                float shift = (luminance - 0.5) * 4.0 * uTexelWidth;

                float red = texture2D(uTexSampler, vTexSamplingCoord + vec2(shift, 0.0)).r;
                vec3 cyanSample = texture2D(uTexSampler, vTexSamplingCoord - vec2(shift, 0.0)).rgb;

                gl_FragColor = vec4(red, cyanSample.g, cyanSample.b, 1.0);
            }
        """
    }
}

