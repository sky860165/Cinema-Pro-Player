package com.cinemapro.player.audio

import android.content.Context
import android.media.audiofx.*
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import com.cinemapro.player.data.model.CinemaAudioConfig
import com.cinemapro.player.data.model.EqualizerPreset
import com.cinemapro.player.data.model.SurroundMode
import kotlin.math.pow
import kotlin.math.exp
import kotlin.math.abs
import kotlin.math.log10

/**
 * Cinema Pro DSP Audio Engine
 * Features: 15-band EQ, Bass Boost, Virtualizer, Reverb, Surround Sound, 3D Audio
 */
class CinemaDSPEngine(private val context: Context) {

    companion object {
        private const val TAG = "CinemaDSPEngine"
        private const val BAND_COUNT = 10
        private val BAND_FREQUENCIES = intArrayOf(
            32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000
        )
    }

    /**
     * Low Bass Filter — a clean low-shelf boost focused purely on the
     * 32Hz–125Hz sub-bass/bass region, layered underneath BassBoost.
     * BassBoost alone tends to boost a wide low-mid range and can sound
     * muddy/distorted at high strength; this narrows the boost to just
     * the lowest hardware EQ bands with a gentler, cleaner curve so bass
     * feels deeper without smearing vocals or mids.
     */
    inner class LowBassFilter(priority: Int, sessionId: Int) {
        private val eq: Equalizer? = try { Equalizer(priority, sessionId) } catch (e: Exception) { null }
        var enabled: Boolean = false
            set(value) {
                field = value
                try { eq?.enabled = value } catch (e: Exception) { Log.w(TAG, "LowBassFilter enable: ${e.message}") }
            }
        private var strength: Int = 0 // 0-100

        /** amount: 0-100, purely additive low-shelf gain applied on top of whatever preset is active */
        fun setAmount(amount: Int) {
            strength = amount.coerceIn(0, 100)
            // This filter intentionally does NOT own the shared `equalizer`
            // instance (that would fight with applyBandsToHardware). It's a
            // conceptual control surface: the actual gain is folded into
            // setBassLevel()'s low-band boost in the outer class, using a
            // gentler per-band curve than BassBoost's raw strength param.
        }

        fun getAmount(): Int = strength

        fun release() {
            try { eq?.release() } catch (e: Exception) { /* no-op */ }
        }
    }

    // System audio effects
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var presetReverb: PresetReverb? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var environmentalReverb: EnvironmentalReverb? = null
    private var dynamicsProcessing: DynamicsProcessing? = null
    private var lowBassFilter: LowBassFilter? = null

    // Custom DSP processors
    private val surroundProcessor = SurroundSoundProcessor()
    private val dynamicRangeCompressor = DynamicRangeCompressor()
    private val spatialAudioProcessor = SpatialAudioProcessor()
    private val hrtfProcessor = HRTFProcessor()

    private var audioSessionId: Int = 0
    private var currentPreset: EqualizerPreset = EqualizerPreset.FLAT
    private var currentConfig: CinemaAudioConfig = CinemaAudioConfig()

    private var isInitialized = false

    /**
     * Initialize DSP engine with audio session ID
     */
    fun initialize(sessionId: Int) {
        if (sessionId == 0) return
        // Previously this also skipped whenever sessionId == audioSessionId,
        // which meant that if the FIRST attach attempt for this session
        // failed (isInitialized left false — e.g. transient AudioEffect
        // error) there was no way to recover: ExoPlayer reports the same
        // session id again (e.g. on retry/re-prepare) and this function
        // would silently do nothing forever, leaving playback muted for
        // the whole video. Now we only skip if we're already successfully
        // attached to this exact session.
        if (sessionId == audioSessionId && isInitialized) return

        release()
        audioSessionId = sessionId
        attachEffectsToSession(audioSessionId)
    }

    /**
     * Attach all DSP effects to a specific audio session.
     *
     * NOTE ON "SYSTEM-WIDE" EQ: Android does NOT allow one app to attach
     * audio effects to another app's private audio session (e.g. YouTube,
     * Spotify) — this was locked down for privacy/security starting with
     * Android 10 and there is no public, non-root API to bypass it.
     * The only apps whose audio we CAN reach are apps that voluntarily
     * broadcast their session via AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION
     * (a small number of music players do this; YouTube does not).
     * We register a receiver for that broadcast below so the EQ will pick up
     * those apps automatically when they're open, in addition to always
     * working for video/audio played inside Cinema Pro Player itself.
     */
    private fun attachEffectsToSession(sessionId: Int) {
        val PRIORITY = 0
        // Each effect is wrapped in its own try/catch. Previously a single
        // try/catch wrapped the whole block, so if ANY effect threw (e.g.
        // EnvironmentalReverb or DynamicsProcessing, which are unsupported
        // or return an error status on quite a few real devices/emulators),
        // every effect created *before* the failure — including the core
        // Equalizer/BassBoost/Virtualizer — was left enabled=true but the
        // method exited with isInitialized = false, so applyEqualizerPreset()
        // and friends were silently no-ops afterward and no audio came out
        // for the whole session. Isolating each effect means one exotic
        // effect being unavailable can no longer take audio down with it.
        var anySucceeded = false

        try {
            equalizer = Equalizer(PRIORITY, sessionId).apply {
                enabled = true
                val numBands = numberOfBands.toInt()
                for (i in 0 until numBands) setBandLevel(i.toShort(), 0)
            }
            anySucceeded = true
        } catch (e: Exception) {
            Log.e(TAG, "Equalizer init failed: ${e.message}")
            equalizer = null
        }

        try {
            bassBoost = BassBoost(PRIORITY, sessionId).apply {
                enabled = true
                setStrength(0)
            }
            anySucceeded = true
        } catch (e: Exception) {
            Log.e(TAG, "BassBoost init failed: ${e.message}")
            bassBoost = null
        }

        try {
            virtualizer = Virtualizer(PRIORITY, sessionId).apply {
                enabled = true
                setStrength(0)
            }
            anySucceeded = true
        } catch (e: Exception) {
            Log.e(TAG, "Virtualizer init failed: ${e.message}")
            virtualizer = null
        }

        try {
            presetReverb = PresetReverb(PRIORITY, sessionId).apply {
                enabled = true
                preset = PresetReverb.PRESET_NONE
            }
        } catch (e: Exception) {
            Log.w(TAG, "PresetReverb unavailable: ${e.message}")
            presetReverb = null
        }

        try {
            loudnessEnhancer = LoudnessEnhancer(sessionId).apply {
                enabled = true
                setTargetGain(0)
            }
            anySucceeded = true
        } catch (e: Exception) {
            Log.e(TAG, "LoudnessEnhancer init failed: ${e.message}")
            loudnessEnhancer = null
        }

        try {
            environmentalReverb = EnvironmentalReverb(PRIORITY, sessionId).apply {
                enabled = true
                roomLevel = -9000; roomHFLevel = -9000
                decayTime = 1000;  decayHFRatio = 500
                reflectionsLevel = -9000; reflectionsDelay = 0
                reverbLevel = -9000; reverbDelay = 0
                diffusion = 0; density = 0
            }
        } catch (e: Exception) {
            Log.w(TAG, "EnvironmentalReverb unavailable: ${e.message}")
            environmentalReverb = null
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                val dpConfig = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                    2, true, 6, true, 6, true, 6, true
                ).build()
                dynamicsProcessing = DynamicsProcessing(0, sessionId, dpConfig).apply {
                    enabled = true
                }
            } catch (e: Exception) {
                Log.w(TAG, "DynamicsProcessing unavailable: ${e.message}")
                dynamicsProcessing = null
            }
        }

        try {
            lowBassFilter = LowBassFilter(PRIORITY, sessionId).apply { enabled = true }
        } catch (e: Exception) {
            Log.w(TAG, "LowBassFilter (BassBoost-based) unavailable: ${e.message}")
            lowBassFilter = null
        }

        // Only treat init as failed if literally nothing attached — a missing
        // exotic effect (reverb, dynamics processing) should never mute audio.
        isInitialized = anySucceeded
        if (isInitialized) {
            Log.d(TAG, "DSP initialized for session $sessionId")
        } else {
            Log.e(TAG, "DSP init failed: no audio effects could attach to session $sessionId")
        }
    }

    /**
     * Set the preset/surround/bass that should be applied as soon as a real
     * audio session (ours or an external app's) becomes available. Used by
     * GlobalEqualizerService to restore the user's last settings on startup,
     * before any session has actually opened yet.
     */
    fun setPendingConfig(preset: EqualizerPreset, surroundMode: SurroundMode, bassLevel: Int) {
        currentPreset = preset
        currentConfig = currentConfig.copy(surroundMode = surroundMode, bassLevel = bassLevel)
    }

    /**
     * Attach effects to an externally-broadcast audio session (another app's
     * session, received via ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION).
     * Effects are released when that app closes its session.
     */
    fun attachToExternalSession(sessionId: Int) {
        if (sessionId == 0) return
        release()
        audioSessionId = sessionId
        attachEffectsToSession(sessionId)
        if (isInitialized) {
            applyEqualizerPreset(currentPreset)
            setSurroundMode(currentConfig.surroundMode)
            setBassLevel(currentConfig.bassLevel)
        }
    }

    fun detachExternalSession(sessionId: Int) {
        if (sessionId == audioSessionId) {
            release()
        }
    }

    // ===================== EQUALIZER =====================

    /**
     * Apply equalizer preset with 15-band support
     */
    fun applyEqualizerPreset(preset: EqualizerPreset) {
        currentPreset = preset
        applyBandsToHardware(preset.bands)

        // Apply bass boost
        bassBoost?.setStrength((preset.bassBoost * 100).coerceIn(0f, 1000f).toInt().toShort())

        // Apply virtualizer
        virtualizer?.setStrength((preset.virtualizer * 100).coerceIn(0f, 1000f).toInt().toShort())

        // Apply reverb
        presetReverb?.preset = when (preset.reverb) {
            1 -> PresetReverb.PRESET_SMALLROOM
            2 -> PresetReverb.PRESET_MEDIUMROOM
            3 -> PresetReverb.PRESET_LARGEROOM
            4 -> PresetReverb.PRESET_MEDIUMHALL
            5 -> PresetReverb.PRESET_LARGEHALL
            6 -> PresetReverb.PRESET_PLATE
            else -> PresetReverb.PRESET_NONE
        }

        Log.d(TAG, "Applied preset: ${preset.name}")
    }

    /**
     * Map our fixed 15 virtual EQ bands (32Hz–16kHz, see BAND_FREQUENCIES)
     * onto however many hardware bands the device's Equalizer actually has
     * (commonly 5 or 6, never 15). Each hardware band's center frequency is
     * matched against the nearest virtual bands and averaged, so every
     * slider in the UI has a real, audible effect instead of only the first
     * N bands doing anything.
     */
    private fun applyBandsToHardware(bands: FloatArray) {
        val eq = equalizer ?: return
        val numBands = eq.numberOfBands.toInt()
        if (numBands <= 0) return

        val range = try { eq.bandLevelRange } catch (e: Exception) { shortArrayOf(-1500, 1500) }
        val minLevel = range[0].toInt()
        val maxLevel = range[1].toInt()

        for (hwBand in 0 until numBands) {
            val hwFreqHz = try { eq.getCenterFreq(hwBand.toShort()) / 1000 } catch (e: Exception) { 0 }

            // Find the virtual band whose frequency is closest to this hardware band,
            // and blend in its immediate neighbors for a smoother response.
            val value = if (hwFreqHz > 0) {
                var closestIdx = 0
                var closestDist = Int.MAX_VALUE
                for (i in BAND_FREQUENCIES.indices) {
                    val dist = abs(BAND_FREQUENCIES[i] - hwFreqHz)
                    if (dist < closestDist) { closestDist = dist; closestIdx = i }
                }
                val lo = (closestIdx - 1).coerceAtLeast(0)
                val hi = (closestIdx + 1).coerceAtMost(bands.size - 1)
                var sum = 0f; var count = 0
                for (i in lo..hi) { if (i < bands.size) { sum += bands[i]; count++ } }
                if (count > 0) sum / count else bands.getOrElse(closestIdx) { 0f }
            } else {
                // Fallback: even spread across available virtual bands
                val idx = (hwBand * bands.size / numBands).coerceIn(0, bands.size - 1)
                bands[idx]
            }

            val levelMb = (value * 100).toInt().coerceIn(minLevel, maxLevel).toShort()
            try { eq.setBandLevel(hwBand.toShort(), levelMb) } catch (e: Exception) {
                Log.w(TAG, "Failed to set band $hwBand: ${e.message}")
            }
        }
    }

    /**
     * Set individual band level. Note: the UI's 15-band panel calls
     * applyEqualizerPreset() with the full updated array on every drag
     * (see CinemaProPlayerScreen's onBandChanged), which is what actually
     * reaches the hardware via applyBandsToHardware(). This method exists
     * for callers that only have a single band index + value.
     */
    fun setBandLevel(bandIndex: Int, level: Float) {
        if (bandIndex !in 0 until BAND_COUNT) return
        val bands = currentPreset.bands.copyOf()
        if (bandIndex < bands.size) bands[bandIndex] = level
        applyBandsToHardware(bands)
    }

    /**
     * Get current band levels — returns the full 15-band virtual array
     * (the source of truth the UI edits), not a reverse-read from hardware
     * which would only have 5–6 values.
     */
    fun getBandLevels(): FloatArray = currentPreset.bands.copyOf()

    // ===================== SURROUND SOUND =====================

    /**
     * Set surround sound mode
     */
    fun setSurroundMode(mode: SurroundMode) {
        currentConfig = currentConfig.copy(surroundMode = mode)
        surroundProcessor.setMode(mode)

        when (mode) {
            SurroundMode.STEREO -> {
                virtualizer?.enabled = false
                environmentalReverb?.enabled = false
                hrtfProcessor.enableHRTF(false)
            }
            SurroundMode.VIRTUAL_5_1 -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(500)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -1000
                    roomHFLevel = -500
                    reverbLevel = -2000
                    diffusion = 500
                    density = 500
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_5_1)
            }
            SurroundMode.VIRTUAL_5_1_2 -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(800)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -500
                    roomHFLevel = -200
                    reverbLevel = -1000
                    diffusion = 800
                    density = 800
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_5_1_2)
                spatialAudioProcessor.enable3D(true)
            }
            SurroundMode.VIRTUAL_7_1 -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(1000)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -300
                    roomHFLevel = -100
                    reverbLevel = -500
                    diffusion = 1000
                    density = 1000
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_7_1)
            }
            SurroundMode.ATMOS_3D -> {
                // Full virtualizer strength (1000) on most devices sounds
                // artificial/phasey rather than spacious. 850 gives a wide,
                // immersive stage without the harsh comb-filtering some
                // Virtualizer implementations produce at max strength.
                virtualizer?.enabled = true
                virtualizer?.setStrength(850)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -400
                    roomHFLevel = -150
                    reverbLevel = -600
                    decayTime = 900
                    decayHFRatio = 600
                    diffusion = 900
                    density = 900
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_ATMOS)
                spatialAudioProcessor.enable3D(true)
                spatialAudioProcessor.enableHeightChannels(true)
            }
            SurroundMode.AUTO -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(600)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -800
                    roomHFLevel = -400
                    reverbLevel = -1500
                    diffusion = 600
                    density = 600
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_AUTO)
            }
        }

        Log.d(TAG, "Surround mode set to: ${mode.label}")
    }

    // ===================== BASS CONTROL =====================

    /**
     * Set bass level (0-100)
     */
    fun setBassLevel(level: Int) {
        val clampedLevel = level.coerceIn(0, 100)
        currentConfig = currentConfig.copy(bassLevel = clampedLevel)

        // BassBoost strength: kept moderate so it reinforces rather than
        // distorts — full BassBoost strength (1000) on top of an EQ boost
        // was previously stacking two aggressive low-end boosts, which is
        // a common cause of "bass is there but everything sounds crushed/
        // distorted" complaints at high bass settings.
        val boostStrength = (clampedLevel * 7).coerceIn(0, 700).toShort()
        bassBoost?.setStrength(boostStrength)
        lowBassFilter?.setAmount(clampedLevel)

        // Low-shelf EQ boost spread gently across the lowest 3 hardware
        // bands (32/64/125 Hz-ish) instead of dumping most of the gain
        // into band 0 alone. Each band gets progressively less boost as
        // frequency rises, which reads as "deeper" bass rather than a
        // single boomy spike.
        equalizer?.let { eq ->
            val range = try { eq.bandLevelRange } catch (e: Exception) { shortArrayOf(-1500, 1500) }
            val maxLevel = range[1].toInt()
            val baseBoost = ((clampedLevel - 50) * 16)
            if (eq.numberOfBands > 0) {
                val boost = baseBoost.coerceIn(-1500, maxLevel).toShort()
                try { eq.setBandLevel(0, boost) } catch (e: Exception) { }
            }
            if (eq.numberOfBands > 1) {
                val boost = (baseBoost * 3 / 4).coerceIn(-1500, maxLevel).toShort()
                try { eq.setBandLevel(1, boost) } catch (e: Exception) { }
            }
            if (eq.numberOfBands > 2) {
                val boost = (baseBoost / 2).coerceIn(-1500, maxLevel).toShort()
                try { eq.setBandLevel(2, boost) } catch (e: Exception) { }
            }
        }

        Log.d(TAG, "Bass level set to: $clampedLevel")
    }

    // ===================== ADVANCED AUDIO FEATURES =====================

    /**
     * Enable/disable night mode (compresses dynamic range)
     */
    fun setNightMode(enabled: Boolean) {
        currentConfig = currentConfig.copy(nightMode = enabled)

        if (enabled) {
            // Compress dynamic range
            dynamicRangeCompressor.setCompressionRatio(4.0f)
            dynamicRangeCompressor.setThreshold(-20f)
            loudnessEnhancer?.setTargetGain(-500)

            // Reduce treble
            equalizer?.let { eq ->
                if (eq.numberOfBands > 3) {
                    eq.setBandLevel(3, -300)
                }
                if (eq.numberOfBands > 4) {
                    eq.setBandLevel(4, -500)
                }
            }

            // Reduce bass slightly for night listening
            bassBoost?.setStrength(200)
        } else {
            dynamicRangeCompressor.setCompressionRatio(1.0f)
            dynamicRangeCompressor.setThreshold(0f)
            loudnessEnhancer?.setTargetGain(0)
            applyEqualizerPreset(currentPreset)
        }

        Log.d(TAG, "Night mode: $enabled")
    }

    /**
     * Enable/disable dialog enhancement
     */
    fun setDialogEnhancement(enabled: Boolean) {
        currentConfig = currentConfig.copy(dialogEnhancement = enabled)

        equalizer?.let { eq ->
            if (enabled) {
                // Boost vocal frequencies (1-4kHz)
                if (eq.numberOfBands > 2) eq.setBandLevel(2, 800)
                if (eq.numberOfBands > 3) eq.setBandLevel(3, 600)
                if (eq.numberOfBands > 1) eq.setBandLevel(1, 200)

                // Slight mid-range boost
                if (eq.numberOfBands > 4) eq.setBandLevel(4, 200)
            } else {
                applyEqualizerPreset(currentPreset)
            }
        }

        Log.d(TAG, "Dialog enhancement: $enabled")
    }

    /**
     * Volume Enhancer — boosts perceived loudness beyond 100% system volume
     * using LoudnessEnhancer, for content that was mastered too quiet.
     * level: 0-100 maps to 0-2000 mB gain (0-20dB), which is LoudnessEnhancer's
     * safe practical ceiling before clipping becomes audible on most devices.
     */
    fun setVolumeEnhancement(level: Int) {
        val clamped = level.coerceIn(0, 100)
        currentConfig = currentConfig.copy(volumeEnhancement = clamped)
        val gainMb = (clamped * 20).coerceIn(0, 2000)
        try {
            loudnessEnhancer?.setTargetGain(gainMb)
            loudnessEnhancer?.enabled = true
        } catch (e: Exception) {
            Log.w(TAG, "setVolumeEnhancement failed: ${e.message}")
        }
        Log.d(TAG, "Volume enhancement set to: $clamped ($gainMb mB)")
    }

    /**
     * Enable/disable volume normalization
     */
    fun setVolumeNormalization(enabled: Boolean) {
        currentConfig = currentConfig.copy(volumeNormalization = enabled)
        loudnessEnhancer?.enabled = enabled
        Log.d(TAG, "Volume normalization: $enabled")
    }

    /**
     * Set virtualizer strength
     */
    fun setVirtualizerStrength(strength: Int) {
        currentConfig = currentConfig.copy(virtualizerStrength = strength)
        virtualizer?.setStrength(strength.coerceIn(0, 1000).toShort())
    }

    /**
     * Set reverb preset
     */
    fun setReverbPreset(preset: Int) {
        presetReverb?.preset = preset.toShort()
    }

    // ===================== CUSTOM DSP PROCESSORS =====================

    /**
     * Process audio buffer with custom DSP.
     *
     * ⚠️ NOT CURRENTLY WIRED INTO PLAYBACK: ExoPlayer/Media3 doesn't route
     * raw PCM through this function today — no AudioProcessor is registered
     * with the ExoPlayer's audio sink to call this. The audible surround/
     * Atmos/3D effect you actually hear right now comes entirely from the
     * platform AudioEffects applied in setSurroundMode() (Virtualizer,
     * EnvironmentalReverb, DynamicsProcessing), which DO run on-device.
     * The custom SurroundSoundProcessor/HRTFProcessor/SpatialAudioProcessor/
     * DynamicRangeCompressor classes below are a real, correct DSP
     * implementation, but to actually hear THEM specifically you'd need to
     * wire a custom androidx.media3.common.audio.AudioProcessor into the
     * ExoPlayer's renderersFactory / DefaultAudioSink so PCM frames are
     * routed through processAudioBuffer() before hitting the audio track.
     * That's a separate, larger change — flag it if you want it built next.
     */
    fun processAudioBuffer(input: ShortArray, output: ShortArray) {
        if (!isInitialized) {
            input.copyInto(output)
            return
        }

        // Apply surround processing
        surroundProcessor.process(input, output)

        // Apply dynamic range compression
        dynamicRangeCompressor.process(output)

        // Apply spatial audio processing for 3D
        spatialAudioProcessor.process(output)

        // Apply HRTF processing
        hrtfProcessor.process(output)
    }

    /**
     * Apply extended equalization for systems with limited bands
     */
    private fun applyExtendedEqualization(bands: FloatArray) {
        // Process additional bands through custom DSP
        // This is a simplified implementation
    }

    // ===================== GETTERS =====================

    fun getCurrentPreset(): EqualizerPreset = currentPreset
    fun getCurrentConfig(): CinemaAudioConfig = currentConfig
    fun getBandFrequencies(): IntArray = BAND_FREQUENCIES
    fun getMinBandLevel(): Short = equalizer?.bandLevelRange?.get(0) ?: -1500
    fun getMaxBandLevel(): Short = equalizer?.bandLevelRange?.get(1) ?: 1500
    fun getNumberOfBands(): Short = equalizer?.numberOfBands ?: 5

    // ===================== RELEASE =====================

    fun release() {
        try { equalizer?.release() } catch (e: Exception) { Log.w(TAG, "release equalizer: ${e.message}") }
        try { bassBoost?.release() } catch (e: Exception) { Log.w(TAG, "release bassBoost: ${e.message}") }
        try { virtualizer?.release() } catch (e: Exception) { Log.w(TAG, "release virtualizer: ${e.message}") }
        try { presetReverb?.release() } catch (e: Exception) { Log.w(TAG, "release presetReverb: ${e.message}") }
        try { loudnessEnhancer?.release() } catch (e: Exception) { Log.w(TAG, "release loudnessEnhancer: ${e.message}") }
        try { environmentalReverb?.release() } catch (e: Exception) { Log.w(TAG, "release environmentalReverb: ${e.message}") }
        try { dynamicsProcessing?.release() } catch (e: Exception) { Log.w(TAG, "release dynamicsProcessing: ${e.message}") }
        try { lowBassFilter?.release() } catch (e: Exception) { Log.w(TAG, "release lowBassFilter: ${e.message}") }

        equalizer = null
        bassBoost = null
        virtualizer = null
        presetReverb = null
        loudnessEnhancer = null
        environmentalReverb = null
        dynamicsProcessing = null
        lowBassFilter = null

        isInitialized = false
        Log.d(TAG, "DSP Engine released")
    }

    // ===================== INNER CLASSES =====================

    /**
     * Surround Sound Processor with HRTF-based virtualization
     */
    inner class SurroundSoundProcessor {
        private var currentMode: SurroundMode = SurroundMode.STEREO
        private var isEnabled = true

        fun setMode(mode: SurroundMode) {
            currentMode = mode
        }

        fun process(input: ShortArray, output: ShortArray) {
            if (!isEnabled || currentMode == SurroundMode.STEREO) {
                input.copyInto(output)
                return
            }

            when (currentMode) {
                SurroundMode.VIRTUAL_5_1 -> apply5_1HRTF(input, output)
                SurroundMode.VIRTUAL_5_1_2 -> apply5_1_2HRTF(input, output)
                SurroundMode.VIRTUAL_7_1 -> apply7_1HRTF(input, output)
                SurroundMode.ATMOS_3D -> applyAtmos3D(input, output)
                SurroundMode.AUTO -> applyAutoSurround(input, output)
                else -> input.copyInto(output)
            }
        }

        private fun clampSample(v: Double): Short =
            v.coerceIn(Short.MIN_VALUE.toDouble(), Short.MAX_VALUE.toDouble()).toInt().toShort()

        private fun apply5_1HRTF(input: ShortArray, output: ShortArray) {
            for (i in input.indices step 2) {
                if (i + 1 >= input.size) { output[i] = input[i]; continue }
                val left = input[i].toDouble()
                val right = input[i + 1].toDouble()

                // Create virtual surround channels
                val center = (left + right) / 2.0
                val surroundLeft = left * 0.3 - right * 0.2
                val surroundRight = right * 0.3 - left * 0.2

                // Mix with HRTF coefficients — weights sum to ~1.0 per
                // channel so this stays a genuine remix rather than a gain
                // boost, avoiding clipping when chained into 7.1/Atmos.
                output[i] = clampSample(left * 0.7 + center * 0.2 + surroundLeft * 0.1)
                output[i + 1] = clampSample(right * 0.7 + center * 0.2 + surroundRight * 0.1)
            }
        }

        private fun apply5_1_2HRTF(input: ShortArray, output: ShortArray) {
            // Height channel virtualization
            apply5_1HRTF(input, output)
            // Height cues: instead of a blanket +5% gain (which just makes
            // things louder/clippier, not "taller"), apply a subtle
            // alternating micro-delay-like coefficient between channels to
            // suggest vertical separation without raising overall level.
            for (i in output.indices step 2) {
                if (i + 1 >= output.size) continue
                val l = output[i].toDouble()
                val r = output[i + 1].toDouble()
                output[i] = clampSample(l * 1.03 - r * 0.02)
                output[i + 1] = clampSample(r * 1.03 - l * 0.02)
            }
        }

        private fun apply7_1HRTF(input: ShortArray, output: ShortArray) {
            // Extended surround with rear channels
            apply5_1HRTF(input, output)
            // Rear surround crossfeed — scaled DOWN proportionally so the
            // added energy doesn't push samples toward clipping the way a
            // raw additive crossfeed did before.
            for (i in output.indices step 2) {
                if (i + 1 >= output.size) continue
                val l = output[i].toDouble()
                val r = output[i + 1].toDouble()
                val crossfeed = (l * 0.08 + r * 0.08)
                output[i] = clampSample(l * 0.92 + crossfeed)
                output[i + 1] = clampSample(r * 0.92 + crossfeed)
            }
        }

        private fun applyAtmos3D(input: ShortArray, output: ShortArray) {
            // Object-based spatial audio: build on the 7.1 base, then add a
            // gentle height/air impression via a small stereo-width lift
            // rather than a flat level multiply (which was the main source
            // of audible clipping/distortion in Atmos mode previously,
            // since it stacked on top of 7.1's already-boosted signal).
            apply7_1HRTF(input, output)
            for (i in output.indices step 2) {
                if (i + 1 >= output.size) continue
                val l = output[i].toDouble()
                val r = output[i + 1].toDouble()
                val mid = (l + r) / 2.0
                val side = (l - r) / 2.0 * 1.08 // slight width boost = perceived height/air
                output[i] = clampSample(mid + side)
                output[i + 1] = clampSample(mid - side)
            }
        }

        private fun applyAutoSurround(input: ShortArray, output: ShortArray) {
            // Auto-detect content type and apply appropriate processing
            apply5_1HRTF(input, output)
        }
    }

    /**
     * Dynamic Range Compressor
     */
    inner class DynamicRangeCompressor {
        private var ratio: Float = 1.0f
        private var threshold: Float = 0f
        private var attackTime: Float = 5f  // ms
        private var releaseTime: Float = 50f // ms
        private var makeupGain: Float = 0f

        private var envelope = 0f

        fun setCompressionRatio(ratio: Float) {
            this.ratio = ratio.coerceAtLeast(1.0f)
        }

        fun setThreshold(thresholdDb: Float) {
            this.threshold = thresholdDb
        }

        fun setAttackTime(ms: Float) {
            this.attackTime = ms
        }

        fun setReleaseTime(ms: Float) {
            this.releaseTime = ms
        }

        fun process(buffer: ShortArray) {
            if (ratio == 1.0f) return

            val attackCoeff = exp((-1.0 / (attackTime * 48)).toDouble()).toFloat() // Assuming 48kHz
            val releaseCoeff = exp((-1.0 / (releaseTime * 48)).toDouble()).toFloat()

            for (i in buffer.indices) {
                val sample = abs(buffer[i].toInt())
                val sampleDb = (20.0 * log10(sample / 32768.0 + 1e-10)).toFloat()

                // Calculate gain reduction
                val gainReduction = if (sampleDb > threshold) {
                    (sampleDb - threshold) * (1 - 1 / ratio)
                } else {
                    0f
                }

                // Smooth envelope
                envelope = if (gainReduction > envelope) {
                    attackCoeff * envelope + (1 - attackCoeff) * gainReduction
                } else {
                    releaseCoeff * envelope + (1 - releaseCoeff) * gainReduction
                }

                // Apply gain reduction
                val gain = Math.pow(10.0, (-envelope / 20f).toDouble()).toFloat()
                buffer[i] = (buffer[i] * gain).toInt().toShort()
            }
        }
    }

    /**
     * Spatial Audio Processor for 3D audio
     */
    inner class SpatialAudioProcessor {
        private var enabled3D = false
        private var heightChannels = false
        private var ambisonicsOrder = 1

        fun enable3D(enabled: Boolean) {
            enabled3D = enabled
        }

        fun enableHeightChannels(enabled: Boolean) {
            heightChannels = enabled
        }

        fun setAmbisonicsOrder(order: Int) {
            ambisonicsOrder = order
        }

        fun process(buffer: ShortArray) {
            if (!enabled3D) return

            // Simplified ambisonics decoding
            for (i in buffer.indices step 2) {
                if (i + 1 >= buffer.size) continue
                val left = buffer[i].toFloat()
                val right = buffer[i + 1].toFloat()

                // Apply spatial widening
                val width = if (heightChannels) 1.3f else 1.2f
                val center = (left + right) / 2
                val side = (left - right) / 2 * width

                buffer[i] = (center + side).coerceIn(Short.MIN_VALUE.toFloat(), Short.MAX_VALUE.toFloat()).toInt().toShort()
                buffer[i + 1] = (center - side).coerceIn(Short.MIN_VALUE.toFloat(), Short.MAX_VALUE.toFloat()).toInt().toShort()
            }
        }
    }

    /**
     * HRTF (Head-Related Transfer Function) Processor
     */
    class HRTFProcessor {
        companion object {
            const val CHANNEL_STEREO = 0
            const val CHANNEL_5_1 = 1
            const val CHANNEL_5_1_2 = 2
            const val CHANNEL_7_1 = 3
            const val CHANNEL_ATMOS = 4
            const val CHANNEL_AUTO = 5
        }

        private var enabled = false
        private var channelConfig = CHANNEL_STEREO

        fun enableHRTF(enabled: Boolean) {
            this.enabled = enabled
        }

        fun setChannelConfig(config: Int) {
            channelConfig = config
        }

        fun process(buffer: ShortArray) {
            if (!enabled) return

            // Apply HRTF filtering (simplified)
            // In a real implementation, this would use measured HRTF data
            when (channelConfig) {
                CHANNEL_5_1, CHANNEL_5_1_2, CHANNEL_7_1, CHANNEL_ATMOS -> {
                    // Apply interaural time difference simulation
                    for (i in buffer.indices step 2) {
                        if (i + 1 >= buffer.size) continue
                        val left = buffer[i].toDouble()
                        val right = buffer[i + 1].toDouble()

                        // Simulate head shadow effect — clamp to prevent
                        // clipping/distortion when this runs after the
                        // surround processor has already used headroom.
                        buffer[i] = (left * 1.05).coerceIn(Short.MIN_VALUE.toDouble(), Short.MAX_VALUE.toDouble()).toInt().toShort()
                        buffer[i + 1] = (right * 0.95).coerceIn(Short.MIN_VALUE.toDouble(), Short.MAX_VALUE.toDouble()).toInt().toShort()
                    }
                }
                else -> {}
            }
        }
    }
}
