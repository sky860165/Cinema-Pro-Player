package com.cinemapro.player.audio

import android.content.Context
import android.media.audiofx.*
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import com.cinemapro.player.data.model.CinemaAudioConfig
import com.cinemapro.player.data.model.EqualizerPreset
import com.cinemapro.player.data.model.SurroundMode
import kotlin.math.pow
import kotlin.math.exp
import kotlin.math.abs
import kotlin.math.log10

/**
 * Cinema Pro DSP Audio Engine
 * Features: 15-band EQ, Bass Boost, Virtualizer, Reverb, Surround Sound, 3D Audio
 */
class CinemaDSPEngine(private val context: Context) {

    companion object {
        private const val TAG = "CinemaDSPEngine"
        private const val BAND_COUNT = 15
        private val BAND_FREQUENCIES = intArrayOf(
            32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000
        )
    }

    // System audio effects
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var presetReverb: PresetReverb? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var environmentalReverb: EnvironmentalReverb? = null
    private var dynamicsProcessing: DynamicsProcessing? = null

    // Custom DSP processors
    private val surroundProcessor = SurroundSoundProcessor()
    private val dynamicRangeCompressor = DynamicRangeCompressor()
    private val spatialAudioProcessor = SpatialAudioProcessor()
    private val hrtfProcessor = HRTFProcessor()

    private var audioSessionId: Int = 0
    private var currentPreset: EqualizerPreset = EqualizerPreset.FLAT
    private var currentConfig: CinemaAudioConfig = CinemaAudioConfig()

    private var isInitialized = false

    /**
     * Initialize DSP engine with audio session ID
     */
    fun initialize(sessionId: Int) {
        if (sessionId == 0 || sessionId == audioSessionId) return

        release()
        audioSessionId = sessionId
        attachEffectsToSession(audioSessionId)
    }

    /**
     * Attach all DSP effects to a specific audio session.
     *
     * NOTE ON "SYSTEM-WIDE" EQ: Android does NOT allow one app to attach
     * audio effects to another app's private audio session (e.g. YouTube,
     * Spotify) — this was locked down for privacy/security starting with
     * Android 10 and there is no public, non-root API to bypass it.
     * The only apps whose audio we CAN reach are apps that voluntarily
     * broadcast their session via AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION
     * (a small number of music players do this; YouTube does not).
     * We register a receiver for that broadcast below so the EQ will pick up
     * those apps automatically when they're open, in addition to always
     * working for video/audio played inside Cinema Pro Player itself.
     */
    private fun attachEffectsToSession(sessionId: Int) {
        val PRIORITY = 0

        try {
            equalizer = Equalizer(PRIORITY, sessionId).apply {
                enabled = true
                val numBands = numberOfBands.toInt()
                for (i in 0 until numBands) setBandLevel(i.toShort(), 0)
            }

            bassBoost = BassBoost(PRIORITY, sessionId).apply {
                enabled = true
                setStrength(0)
            }

            virtualizer = Virtualizer(PRIORITY, sessionId).apply {
                enabled = true
                setStrength(0)
            }

            presetReverb = PresetReverb(PRIORITY, sessionId).apply {
                enabled = true
                preset = PresetReverb.PRESET_NONE
            }

            loudnessEnhancer = LoudnessEnhancer(sessionId).apply {
                enabled = true
                setTargetGain(0)
            }

            environmentalReverb = EnvironmentalReverb(PRIORITY, sessionId).apply {
                enabled = true
                roomLevel = -9000; roomHFLevel = -9000
                decayTime = 1000;  decayHFRatio = 500
                reflectionsLevel = -9000; reflectionsDelay = 0
                reverbLevel = -9000; reverbDelay = 0
                diffusion = 0; density = 0
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try {
                    val dpConfig = DynamicsProcessing.Config.Builder(
                        DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                        2, true, 6, true, 6, true, 6, true
                    ).build()
                    dynamicsProcessing = DynamicsProcessing(0, audioSessionId, dpConfig).apply {
                        enabled = true
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "DynamicsProcessing unavailable: ${e.message}")
                }
            }

            isInitialized = true
            Log.d(TAG, "DSP initialized for session $sessionId")

        } catch (e: Exception) {
            Log.e(TAG, "DSP init failed: ${e.message}")
            isInitialized = false
        }
    }

    /**
     * Set the preset/surround/bass that should be applied as soon as a real
     * audio session (ours or an external app's) becomes available. Used by
     * GlobalEqualizerService to restore the user's last settings on startup,
     * before any session has actually opened yet.
     */
    fun setPendingConfig(preset: EqualizerPreset, surroundMode: SurroundMode, bassLevel: Int) {
        currentPreset = preset
        currentConfig = currentConfig.copy(surroundMode = surroundMode, bassLevel = bassLevel)
    }

    /**
     * Attach effects to an externally-broadcast audio session (another app's
     * session, received via ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION).
     * Effects are released when that app closes its session.
     */
    fun attachToExternalSession(sessionId: Int) {
        if (sessionId == 0) return
        release()
        audioSessionId = sessionId
        attachEffectsToSession(sessionId)
        if (isInitialized) {
            applyEqualizerPreset(currentPreset)
            setSurroundMode(currentConfig.surroundMode)
            setBassLevel(currentConfig.bassLevel)
        }
    }

    fun detachExternalSession(sessionId: Int) {
        if (sessionId == audioSessionId) {
            release()
        }
    }

    // ===================== EQUALIZER =====================

    /**
     * Apply equalizer preset with 15-band support
     */
    fun applyEqualizerPreset(preset: EqualizerPreset) {
        currentPreset = preset

        equalizer?.let { eq ->
            val numBands = eq.numberOfBands.toInt()
            val bands = preset.bands

            // Map 15 bands to available equalizer bands
            for (i in 0 until minOf(numBands, bands.size)) {
                val level = (bands[i] * 100).toInt().coerceIn(-1500, 1500).toShort()
                eq.setBandLevel(i.toShort(), level)
            }

            // For systems with only 5 bands, apply additional processing for remaining bands
            if (numBands < bands.size) {
                applyExtendedEqualization(bands)
            }
        }

        // Apply bass boost
        bassBoost?.setStrength((preset.bassBoost * 100).coerceIn(0f, 1000f).toInt().toShort())

        // Apply virtualizer
        virtualizer?.setStrength((preset.virtualizer * 100).coerceIn(0f, 1000f).toInt().toShort())

        // Apply reverb
        presetReverb?.preset = when (preset.reverb) {
            1 -> PresetReverb.PRESET_SMALLROOM
            2 -> PresetReverb.PRESET_MEDIUMROOM
            3 -> PresetReverb.PRESET_LARGEROOM
            4 -> PresetReverb.PRESET_MEDIUMHALL
            5 -> PresetReverb.PRESET_LARGEHALL
            6 -> PresetReverb.PRESET_PLATE
            else -> PresetReverb.PRESET_NONE
        }

        Log.d(TAG, "Applied preset: ${preset.name}")
    }

    /**
     * Set individual band level
     */
    fun setBandLevel(bandIndex: Int, level: Float) {
        equalizer?.let { eq ->
            if (bandIndex < eq.numberOfBands) {
                val levelValue = (level * 100).toInt().coerceIn(-1500, 1500).toShort()
                eq.setBandLevel(bandIndex.toShort(), levelValue)
            }
        }
    }

    /**
     * Get current band levels
     */
    fun getBandLevels(): FloatArray {
        val levels = FloatArray(BAND_COUNT)
        equalizer?.let { eq ->
            val numBands = minOf(eq.numberOfBands.toInt(), BAND_COUNT)
            for (i in 0 until numBands) {
                levels[i] = eq.getBandLevel(i.toShort()) / 100f
            }
        }
        return levels
    }

    // ===================== SURROUND SOUND =====================

    /**
     * Set surround sound mode
     */
    fun setSurroundMode(mode: SurroundMode) {
        currentConfig = currentConfig.copy(surroundMode = mode)
        surroundProcessor.setMode(mode)

        when (mode) {
            SurroundMode.STEREO -> {
                virtualizer?.enabled = false
                environmentalReverb?.enabled = false
                hrtfProcessor.enableHRTF(false)
            }
            SurroundMode.VIRTUAL_5_1 -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(500)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -1000
                    roomHFLevel = -500
                    reverbLevel = -2000
                    diffusion = 500
                    density = 500
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_5_1)
            }
            SurroundMode.VIRTUAL_5_1_2 -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(800)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -500
                    roomHFLevel = -200
                    reverbLevel = -1000
                    diffusion = 800
                    density = 800
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_5_1_2)
                spatialAudioProcessor.enable3D(true)
            }
            SurroundMode.VIRTUAL_7_1 -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(1000)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -300
                    roomHFLevel = -100
                    reverbLevel = -500
                    diffusion = 1000
                    density = 1000
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_7_1)
            }
            SurroundMode.ATMOS_3D -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(1000)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -100
                    roomHFLevel = 0
                    reverbLevel = -200
                    diffusion = 1000
                    density = 1000
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_ATMOS)
                spatialAudioProcessor.enable3D(true)
                spatialAudioProcessor.enableHeightChannels(true)
            }
            SurroundMode.AUTO -> {
                virtualizer?.enabled = true
                virtualizer?.setStrength(600)
                environmentalReverb?.enabled = true
                environmentalReverb?.apply {
                    roomLevel = -800
                    roomHFLevel = -400
                    reverbLevel = -1500
                    diffusion = 600
                    density = 600
                }
                hrtfProcessor.enableHRTF(true)
                hrtfProcessor.setChannelConfig(HRTFProcessor.CHANNEL_AUTO)
            }
        }

        Log.d(TAG, "Surround mode set to: ${mode.label}")
    }

    // ===================== BASS CONTROL =====================

    /**
     * Set bass level (0-100)
     */
    fun setBassLevel(level: Int) {
        currentConfig = currentConfig.copy(bassLevel = level)
        val strength = (level * 10).coerceIn(0, 1000).toShort()
        bassBoost?.setStrength(strength)

        // Additional low-end EQ boost
        equalizer?.let { eq ->
            if (eq.numberOfBands > 0) {
                val boost = ((level - 50) * 20).coerceIn(-1500, 1500).toShort()
                eq.setBandLevel(0, boost)
            }
            if (eq.numberOfBands > 1) {
                val boost = ((level - 50) * 14).coerceIn(-1500, 1500).toShort()
                eq.setBandLevel(1, boost)
            }
        }

        Log.d(TAG, "Bass level set to: $level")
    }

    // ===================== ADVANCED AUDIO FEATURES =====================

    /**
     * Enable/disable night mode (compresses dynamic range)
     */
    fun setNightMode(enabled: Boolean) {
        currentConfig = currentConfig.copy(nightMode = enabled)

        if (enabled) {
            // Compress dynamic range
            dynamicRangeCompressor.setCompressionRatio(4.0f)
            dynamicRangeCompressor.setThreshold(-20f)
            loudnessEnhancer?.setTargetGain(-500)

            // Reduce treble
            equalizer?.let { eq ->
                if (eq.numberOfBands > 3) {
                    eq.setBandLevel(3, -300)
                }
                if (eq.numberOfBands > 4) {
                    eq.setBandLevel(4, -500)
                }
            }

            // Reduce bass slightly for night listening
            bassBoost?.setStrength(200)
        } else {
            dynamicRangeCompressor.setCompressionRatio(1.0f)
            dynamicRangeCompressor.setThreshold(0f)
            loudnessEnhancer?.setTargetGain(0)
            applyEqualizerPreset(currentPreset)
        }

        Log.d(TAG, "Night mode: $enabled")
    }

    /**
     * Enable/disable dialog enhancement
     */
    fun setDialogEnhancement(enabled: Boolean) {
        currentConfig = currentConfig.copy(dialogEnhancement = enabled)

        equalizer?.let { eq ->
            if (enabled) {
                // Boost vocal frequencies (1-4kHz)
                if (eq.numberOfBands > 2) eq.setBandLevel(2, 800)
                if (eq.numberOfBands > 3) eq.setBandLevel(3, 600)
                if (eq.numberOfBands > 1) eq.setBandLevel(1, 200)

                // Slight mid-range boost
                if (eq.numberOfBands > 4) eq.setBandLevel(4, 200)
            } else {
                applyEqualizerPreset(currentPreset)
            }
        }

        Log.d(TAG, "Dialog enhancement: $enabled")
    }

    /**
     * Enable/disable volume normalization
     */
    fun setVolumeNormalization(enabled: Boolean) {
        currentConfig = currentConfig.copy(volumeNormalization = enabled)
        loudnessEnhancer?.enabled = enabled
        Log.d(TAG, "Volume normalization: $enabled")
    }

    /**
     * Set virtualizer strength
     */
    fun setVirtualizerStrength(strength: Int) {
        currentConfig = currentConfig.copy(virtualizerStrength = strength)
        virtualizer?.setStrength(strength.coerceIn(0, 1000).toShort())
    }

    /**
     * Set reverb preset
     */
    fun setReverbPreset(preset: Int) {
        presetReverb?.preset = preset.toShort()
    }

    // ===================== CUSTOM DSP PROCESSORS =====================

    /**
     * Process audio buffer with custom DSP
     */
    fun processAudioBuffer(input: ShortArray, output: ShortArray) {
        if (!isInitialized) {
            input.copyInto(output)
            return
        }

        // Apply surround processing
        surroundProcessor.process(input, output)

        // Apply dynamic range compression
        dynamicRangeCompressor.process(output)

        // Apply spatial audio processing for 3D
        spatialAudioProcessor.process(output)

        // Apply HRTF processing
        hrtfProcessor.process(output)
    }

    /**
     * Apply extended equalization for systems with limited bands
     */
    private fun applyExtendedEqualization(bands: FloatArray) {
        // Process additional bands through custom DSP
        // This is a simplified implementation
    }

    // ===================== GETTERS =====================

    fun getCurrentPreset(): EqualizerPreset = currentPreset
    fun getCurrentConfig(): CinemaAudioConfig = currentConfig
    fun getBandFrequencies(): IntArray = BAND_FREQUENCIES
    fun getMinBandLevel(): Short = equalizer?.bandLevelRange?.get(0) ?: -1500
    fun getMaxBandLevel(): Short = equalizer?.bandLevelRange?.get(1) ?: 1500
    fun getNumberOfBands(): Short = equalizer?.numberOfBands ?: 5

    // ===================== RELEASE =====================

    fun release() {
        equalizer?.release()
        bassBoost?.release()
        virtualizer?.release()
        presetReverb?.release()
        loudnessEnhancer?.release()
        environmentalReverb?.release()
        dynamicsProcessing?.release()

        equalizer = null
        bassBoost = null
        virtualizer = null
        presetReverb = null
        loudnessEnhancer = null
        environmentalReverb = null
        dynamicsProcessing = null

        isInitialized = false
        Log.d(TAG, "DSP Engine released")
    }

    // ===================== INNER CLASSES =====================

    /**
     * Surround Sound Processor with HRTF-based virtualization
     */
    inner class SurroundSoundProcessor {
        private var currentMode: SurroundMode = SurroundMode.STEREO
        private var isEnabled = true

        fun setMode(mode: SurroundMode) {
            currentMode = mode
        }

        fun process(input: ShortArray, output: ShortArray) {
            if (!isEnabled || currentMode == SurroundMode.STEREO) {
                input.copyInto(output)
                return
            }

            when (currentMode) {
                SurroundMode.VIRTUAL_5_1 -> apply5_1HRTF(input, output)
                SurroundMode.VIRTUAL_5_1_2 -> apply5_1_2HRTF(input, output)
                SurroundMode.VIRTUAL_7_1 -> apply7_1HRTF(input, output)
                SurroundMode.ATMOS_3D -> applyAtmos3D(input, output)
                SurroundMode.AUTO -> applyAutoSurround(input, output)
                else -> input.copyInto(output)
            }
        }

        private fun apply5_1HRTF(input: ShortArray, output: ShortArray) {
            for (i in input.indices step 2) {
                val left = input[i].toInt()
                val right = input[i + 1].toInt()

                // Create virtual surround channels
                val center = ((left + right) / 2).toShort()
                val surroundLeft = (left * 0.3 - right * 0.2).toInt().toShort()
                val surroundRight = (right * 0.3 - left * 0.2).toInt().toShort()

                // Mix with HRTF coefficients
                output[i] = ((left * 0.7 + center * 0.2 + surroundLeft * 0.1).toInt()).toShort()
                output[i + 1] = ((right * 0.7 + center * 0.2 + surroundRight * 0.1).toInt()).toShort()
            }
        }

        private fun apply5_1_2HRTF(input: ShortArray, output: ShortArray) {
            // Height channel virtualization
            apply5_1HRTF(input, output)
            // Add height cues (simplified)
            for (i in output.indices) {
                output[i] = (output[i] * 1.05).toInt().toShort()
            }
        }

        private fun apply7_1HRTF(input: ShortArray, output: ShortArray) {
            // Extended surround with rear channels
            apply5_1HRTF(input, output)
            // Add rear surround (simplified)
            for (i in output.indices step 2) {
                val crossfeed = (output[i] * 0.1 + output[i + 1] * 0.1).toInt().toShort()
                output[i] = (output[i] + crossfeed).toShort()
                output[i + 1] = (output[i + 1] + crossfeed).toShort()
            }
        }

        private fun applyAtmos3D(input: ShortArray, output: ShortArray) {
            // Object-based spatial audio
            apply7_1HRTF(input, output)
            // Add overhead/height dimension
            for (i in output.indices) {
                val sample = output[i].toInt()
                // Simulate height by adding slight phase shift and reverb
                output[i] = (sample * 1.02).toInt().toShort()
            }
        }

        private fun applyAutoSurround(input: ShortArray, output: ShortArray) {
            // Auto-detect content type and apply appropriate processing
            apply5_1HRTF(input, output)
        }
    }

    /**
     * Dynamic Range Compressor
     */
    inner class DynamicRangeCompressor {
        private var ratio: Float = 1.0f
        private var threshold: Float = 0f
        private var attackTime: Float = 5f  // ms
        private var releaseTime: Float = 50f // ms
        private var makeupGain: Float = 0f

        private var envelope = 0f

        fun setCompressionRatio(ratio: Float) {
            this.ratio = ratio.coerceAtLeast(1.0f)
        }

        fun setThreshold(thresholdDb: Float) {
            this.threshold = thresholdDb
        }

        fun setAttackTime(ms: Float) {
            this.attackTime = ms
        }

        fun setReleaseTime(ms: Float) {
            this.releaseTime = ms
        }

        fun process(buffer: ShortArray) {
            if (ratio == 1.0f) return

            val attackCoeff = exp((-1.0 / (attackTime * 48)).toDouble()).toFloat() // Assuming 48kHz
            val releaseCoeff = exp((-1.0 / (releaseTime * 48)).toDouble()).toFloat()

            for (i in buffer.indices) {
                val sample = abs(buffer[i].toInt())
                val sampleDb = (20.0 * log10(sample / 32768.0 + 1e-10)).toFloat()

                // Calculate gain reduction
                val gainReduction = if (sampleDb > threshold) {
                    (sampleDb - threshold) * (1 - 1 / ratio)
                } else {
                    0f
                }

                // Smooth envelope
                envelope = if (gainReduction > envelope) {
                    attackCoeff * envelope + (1 - attackCoeff) * gainReduction
                } else {
                    releaseCoeff * envelope + (1 - releaseCoeff) * gainReduction
                }

                // Apply gain reduction
                val gain = Math.pow(10.0, (-envelope / 20f).toDouble()).toFloat()
                buffer[i] = (buffer[i] * gain).toInt().toShort()
            }
        }
    }

    /**
     * Spatial Audio Processor for 3D audio
     */
    inner class SpatialAudioProcessor {
        private var enabled3D = false
        private var heightChannels = false
        private var ambisonicsOrder = 1

        fun enable3D(enabled: Boolean) {
            enabled3D = enabled
        }

        fun enableHeightChannels(enabled: Boolean) {
            heightChannels = enabled
        }

        fun setAmbisonicsOrder(order: Int) {
            ambisonicsOrder = order
        }

        fun process(buffer: ShortArray) {
            if (!enabled3D) return

            // Simplified ambisonics decoding
            for (i in buffer.indices step 2) {
                val left = buffer[i].toFloat()
                val right = buffer[i + 1].toFloat()

                // Apply spatial widening
                val width = if (heightChannels) 1.3f else 1.2f
                val center = (left + right) / 2
                val side = (left - right) / 2 * width

                buffer[i] = (center + side).toInt().toShort()
                buffer[i + 1] = (center - side).toInt().toShort()
            }
        }
    }

    /**
     * HRTF (Head-Related Transfer Function) Processor
     */
    class HRTFProcessor {
        companion object {
            const val CHANNEL_STEREO = 0
            const val CHANNEL_5_1 = 1
            const val CHANNEL_5_1_2 = 2
            const val CHANNEL_7_1 = 3
            const val CHANNEL_ATMOS = 4
            const val CHANNEL_AUTO = 5
        }

        private var enabled = false
        private var channelConfig = CHANNEL_STEREO

        fun enableHRTF(enabled: Boolean) {
            this.enabled = enabled
        }

        fun setChannelConfig(config: Int) {
            channelConfig = config
        }

        fun process(buffer: ShortArray) {
            if (!enabled) return

            // Apply HRTF filtering (simplified)
            // In a real implementation, this would use measured HRTF data
            when (channelConfig) {
                CHANNEL_5_1, CHANNEL_5_1_2, CHANNEL_7_1, CHANNEL_ATMOS -> {
                    // Apply interaural time difference simulation
                    for (i in buffer.indices step 2) {
                        val left = buffer[i].toInt()
                        val right = buffer[i + 1].toInt()

                        // Simulate head shadow effect
                        buffer[i] = (left * 1.05).toInt().toShort()
                        buffer[i + 1] = (right * 0.95).toInt().toShort()
                    }
                }
                else -> {}
            }
        }
    }
}
