package com.cinemapro.player.ui.screens

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.cinemapro.player.audio.CinemaDSPEngine
import com.cinemapro.player.data.model.*
import com.cinemapro.player.ui.components.*
import com.cinemapro.player.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.abs

@OptIn(UnstableApi::class)
@Composable
fun CinemaProPlayerScreen(
    videoUri: String,
    videoTitle: String = "",
    onBackPressed: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current

    // Player states
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var bufferedPosition by remember { mutableLongStateOf(0L) }
    var showControls by remember { mutableStateOf(true) }
    var isFullscreen by remember { mutableStateOf(false) }
    var isPipMode by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }
    var playerError by remember { mutableStateOf<String?>(null) }

    // Quality & Settings
    var currentQuality by remember { mutableStateOf(VideoQuality.AUTO) }
    var currentUpscale by remember { mutableStateOf(UpscaleMode.OFF) }
    var current3DMode by remember { mutableStateOf(VideoMode3D.OFF) }
    var currentSpeed by remember { mutableFloatStateOf(1.0f) }
    var isLooping by remember { mutableStateOf(false) }

    // Audio
    var currentAudioTrack by remember { mutableStateOf<AudioTrack?>(null) }
    var currentSubtitle by remember { mutableStateOf<SubtitleTrack?>(null) }
    var showEqualizer by remember { mutableStateOf(false) }
    var showAudioTracks by remember { mutableStateOf(false) }
    var showSubtitleTracks by remember { mutableStateOf(false) }
    var showQualitySelector by remember { mutableStateOf(false) }
    var showSpeedSelector by remember { mutableStateOf(false) }
    var show3DSelector by remember { mutableStateOf(false) }
    var showUpscaleSelector by remember { mutableStateOf(false) }

    // DSP Config
    var currentPreset by remember { mutableStateOf(EqualizerPreset.FLAT) }
    var customBands by remember { mutableStateOf(FloatArray(15) { 0f }) }
    var showCustomSaveDialog by remember { mutableStateOf(false) }
    var customPresetName by remember { mutableStateOf("") }
    var surroundMode by remember { mutableStateOf(SurroundMode.AUTO) }
    var bassLevel by remember { mutableIntStateOf(50) }
    var nightMode by remember { mutableStateOf(false) }
    var dialogEnhance by remember { mutableStateOf(false) }
    var volumeNormalization by remember { mutableStateOf(true) }

    // Tracks
    var audioTracks by remember { mutableStateOf<List<AudioTrack>>(emptyList()) }
    var subtitleTracks by remember { mutableStateOf<List<SubtitleTrack>>(emptyList()) }

    // Gesture
    var isDragging by remember { mutableStateOf(false) }
    var dragStartPosition by remember { mutableLongStateOf(0L) }

    // DSP Engine
    val dspEngine = remember { CinemaDSPEngine(context) }

    // ExoPlayer
    val trackSelector = remember {
        DefaultTrackSelector(context).apply {
            setParameters(
                buildUponParameters()
                    .setMaxVideoSize(7680, 4320)
                    .setMaxVideoBitrate(100_000_000)
            )
        }
    }

    val exoPlayer = remember {
        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .build()
            .apply {
                setMediaItem(MediaItem.fromUri(videoUri))
                prepare()
                playWhenReady = true
            }
    }

    // Initialize DSP
    LaunchedEffect(exoPlayer.audioSessionId) {
        if (exoPlayer.audioSessionId != 0) {
            dspEngine.initialize(exoPlayer.audioSessionId)
            dspEngine.applyEqualizerPreset(currentPreset)
            dspEngine.setSurroundMode(surroundMode)
            dspEngine.setBassLevel(bassLevel)
            dspEngine.setNightMode(nightMode)
            dspEngine.setDialogEnhancement(dialogEnhance)
            dspEngine.setVolumeNormalization(volumeNormalization)
        }
    }

    // Progress
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            currentPosition = exoPlayer.currentPosition
            bufferedPosition = exoPlayer.bufferedPosition
            duration = exoPlayer.duration.coerceAtLeast(0)
            isLoading = exoPlayer.isLoading && !exoPlayer.isPlaying
            delay(100)
        }
    }

    // Auto-hide controls
    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying && !isDragging) {
            delay(4000)
            showControls = false
        }
    }

    // Extract tracks
    LaunchedEffect(exoPlayer.currentTracks) {
        val tracks = exoPlayer.currentTracks
        val audioList = mutableListOf<AudioTrack>()
        val subtitleList = mutableListOf<SubtitleTrack>()

        for (group in tracks.groups) {
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                when {
                    format.sampleMimeType?.startsWith("audio") == true -> {
                        audioList.add(
                            AudioTrack(
                                id = "${group.mediaTrackGroup.id}_$i",
                                language = format.language ?: "Unknown",
                                label = format.label ?: "Track ${audioList.size + 1}",
                                isDefault = group.isTrackSelected(i)
                            )
                        )
                    }
                    format.sampleMimeType?.contains("text") == true ||
                    format.sampleMimeType?.contains("subtitle") == true -> {
                        subtitleList.add(
                            SubtitleTrack(
                                id = "${group.mediaTrackGroup.id}_$i",
                                language = format.language ?: "Unknown",
                                label = format.label ?: "Subtitle ${subtitleList.size + 1}"
                            )
                        )
                    }
                }
            }
        }
        audioTracks = audioList
        subtitleTracks = subtitleList
    }

    // Player listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isLoading = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) {
                    duration = exoPlayer.duration.coerceAtLeast(0)
                }
            }
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
            override fun onPlayerError(error: PlaybackException) {
                playerError = error.message
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Lifecycle
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    if (!isPipMode) exoPlayer.playWhenReady = false
                }
                Lifecycle.Event.ON_RESUME -> {
                    exoPlayer.playWhenReady = true
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Back handler
    BackHandler {
        when {
            showEqualizer -> showEqualizer = false
            showAudioTracks -> showAudioTracks = false
            showSubtitleTracks -> showSubtitleTracks = false
            showQualitySelector -> showQualitySelector = false
            showSpeedSelector -> showSpeedSelector = false
            show3DSelector -> show3DSelector = false
            showUpscaleSelector -> showUpscaleSelector = false
            isFullscreen -> {
                isFullscreen = false
                (context as? Activity)?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
            else -> onBackPressed()
        }
    }

    // Fullscreen
    LaunchedEffect(isFullscreen) {
        val activity = context as? Activity
        if (isFullscreen) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // PIP
    fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            (context as? Activity)?.enterPictureInPictureMode(params)
            isPipMode = true
        }
    }

    // UI
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        // Video Player
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { showControls = !showControls },
                        onDoubleTap = { offset ->
                            val width = size.width
                            if (offset.x < width / 2) {
                                exoPlayer.seekTo(exoPlayer.currentPosition - 10000)
                            } else {
                                exoPlayer.seekTo(exoPlayer.currentPosition + 10000)
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { _ ->
                            isDragging = true
                            dragStartPosition = exoPlayer.currentPosition
                            showControls = true
                        },
                        onDragEnd = { isDragging = false },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            val totalWidth = size.width.toFloat()
                            val seekPercent = dragAmount / totalWidth
                            val seekMs = (seekPercent * duration).toLong()
                            exoPlayer.seekTo((dragStartPosition + seekMs).coerceIn(0, duration))
                        }
                    )
                }
        )

        // Loading
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CinemaGold, strokeWidth = 3.dp, modifier = Modifier.size(64.dp))
            }
        }

        // Error
        playerError?.let { error ->
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.9f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Error, null, tint = CinemaRed, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Playback Error", color = CinemaRed, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(error, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
                    Button(onClick = { playerError = null; exoPlayer.prepare() }) { Text("Retry") }
                }
            }
        }

        // AI Upscale Badge
        if (currentUpscale != UpscaleMode.OFF) {
            Box(
                modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CinemaGreen.copy(alpha = 0.9f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "AI ${when(currentUpscale) {
                        UpscaleMode.AI_4K -> "4K"
                        UpscaleMode.AI_8K -> "8K"
                        UpscaleMode.SUPER_RESOLUTION -> "SR"
                        UpscaleMode.SHARPEN -> "SHARP"
                        UpscaleMode.DENOISE -> "DENOISE"
                        UpscaleMode.HDR_SIMULATION -> "HDR"
                        else -> ""
                    }}",
                    color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp
                )
            }
        }

        // 3D Badge
        if (current3DMode != VideoMode3D.OFF) {
            Box(
                modifier = Modifier.align(Alignment.TopStart).padding(16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CinemaBlue.copy(alpha = 0.9f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("3D ${current3DMode.name}", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Cinema Sound Badge
        Box(
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 16.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(CinemaGold.copy(alpha = 0.9f))
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Text("CINEMA PRO SOUND - ${surroundMode.label}", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }

        // Speed indicator
        if (currentSpeed != 1.0f) {
            Box(
                modifier = Modifier.align(Alignment.BottomStart).padding(bottom = 100.dp, start = 16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CinemaPurple.copy(alpha = 0.8f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("${currentSpeed}x", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Controls Overlay
        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(300))
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.8f), Color.Transparent,
                            Color.Transparent, Color.Black.copy(alpha = 0.85f)
                        )
                    )
                )
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp).padding(top = 32.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackPressed) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
                    Text(
                        text = videoTitle.ifEmpty { "CINEMA PRO" },
                        color = CinemaGold, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(horizontal = 16.dp)
                    )
                    Row {
                        IconButton(onClick = { enterPipMode() }) { Icon(Icons.Default.PictureInPicture, "PIP", tint = Color.White) }
                        IconButton(onClick = { showControls = false }) { Icon(Icons.Default.MoreVert, "More", tint = Color.White) }
                    }
                }

                // Center Play/Pause
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Row(horizontalArrangement = Arrangement.spacedBy(32.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { exoPlayer.seekTo(exoPlayer.currentPosition - 10000) },
                            modifier = Modifier.size(56.dp)
                        ) { Icon(Icons.Default.Replay10, "Rewind", tint = Color.White, modifier = Modifier.size(40.dp)) }

                        FloatingActionButton(
                            onClick = { exoPlayer.playWhenReady = !exoPlayer.isPlaying },
                            containerColor = CinemaGold, modifier = Modifier.size(80.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause", tint = Color.Black, modifier = Modifier.size(48.dp)
                            )
                        }

                        IconButton(
                            onClick = { exoPlayer.seekTo(exoPlayer.currentPosition + 10000) },
                            modifier = Modifier.size(56.dp)
                        ) { Icon(Icons.Default.Forward10, "Forward", tint = Color.White, modifier = Modifier.size(40.dp)) }
                    }
                }

                // Bottom Controls
                Column(
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(16.dp)
                ) {
                    // Seek bar
                    Box(modifier = Modifier.fillMaxWidth().height(24.dp)) {
                        Slider(
                            value = bufferedPosition.toFloat(),
                            onValueChange = {},
                            valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = Color.Transparent,
                                activeTrackColor = Color.White.copy(alpha = 0.3f),
                                inactiveTrackColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Slider(
                            value = currentPosition.toFloat(),
                            onValueChange = {
                                exoPlayer.seekTo(it.toLong())
                                currentPosition = it.toLong()
                            },
                            valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = CinemaGold, activeTrackColor = CinemaGold,
                                inactiveTrackColor = Color.Gray.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Time & Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${formatTime(currentPosition)} / ${formatTime(duration)}",
                            color = Color.White, fontSize = 14.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = {
                                isLooping = !isLooping
                                exoPlayer.repeatMode = if (isLooping) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                            }) {
                                Icon(
                                    imageVector = if (isLooping) Icons.Default.RepeatOne else Icons.Default.Repeat,
                                    contentDescription = "Loop", tint = if (isLooping) CinemaGold else Color.White
                                )
                            }
                            IconButton(onClick = { showAudioTracks = true }) { Icon(Icons.Default.Audiotrack, "Audio", tint = Color.White) }
                            IconButton(onClick = { showSubtitleTracks = true }) {
                                Icon(Icons.Default.Subtitles, "Subtitles", tint = if (currentSubtitle != null) CinemaGold else Color.White)
                            }
                            IconButton(onClick = { showEqualizer = true }) {
                                Icon(Icons.Default.Equalizer, "EQ", tint = if (currentPreset != EqualizerPreset.FLAT) CinemaGold else Color.White)
                            }
                            TextButton(onClick = { showQualitySelector = true }) {
                                Text(currentQuality.label, color = CinemaGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            TextButton(onClick = { showSpeedSelector = true }) {
                                Text("${currentSpeed}x", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            TextButton(onClick = { show3DSelector = true }) {
                                Text(if (current3DMode == VideoMode3D.OFF) "2D" else "3D",
                                    color = if (current3DMode != VideoMode3D.OFF) CinemaBlue else Color.White,
                                    fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            TextButton(onClick = { showUpscaleSelector = true }) {
                                Text(if (currentUpscale == UpscaleMode.OFF) "AI" else "AI+",
                                    color = if (currentUpscale != UpscaleMode.OFF) CinemaGreen else Color.White,
                                    fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            IconButton(onClick = { isFullscreen = !isFullscreen }) {
                                Icon(
                                    imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                    contentDescription = "Fullscreen", tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dialogs
        if (showAudioTracks) {
            TrackSelectorDialog("Audio Tracks", audioTracks.map { it.label },
                audioTracks.indexOfFirst { it.isSelected },
                { showAudioTracks = false }, { showAudioTracks = false })
        }
        if (showSubtitleTracks) {
            TrackSelectorDialog("Subtitles", listOf("Off") + subtitleTracks.map { it.label },
                if (currentSubtitle == null) 0 else subtitleTracks.indexOf(currentSubtitle) + 1,
                { idx -> currentSubtitle = if (idx == 0) null else subtitleTracks.getOrNull(idx - 1); showSubtitleTracks = false },
                { showSubtitleTracks = false })
        }
        if (showQualitySelector) {
            TrackSelectorDialog("Video Quality", VideoQuality.values().map { it.label },
                VideoQuality.values().indexOf(currentQuality),
                { idx -> currentQuality = VideoQuality.values()[idx]; showQualitySelector = false },
                { showQualitySelector = false })
        }
        if (showSpeedSelector) {
            val speeds = listOf("0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x")
            TrackSelectorDialog("Playback Speed", speeds,
                listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f).indexOf(currentSpeed),
                { idx ->
                    currentSpeed = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)[idx]
                    exoPlayer.setPlaybackSpeed(currentSpeed)
                    showSpeedSelector = false
                },
                { showSpeedSelector = false })
        }
        if (show3DSelector) {
            TrackSelectorDialog("3D Video Mode", VideoMode3D.values().map { it.label },
                VideoMode3D.values().indexOf(current3DMode),
                { idx -> current3DMode = VideoMode3D.values()[idx]; show3DSelector = false },
                { show3DSelector = false })
        }
        if (showUpscaleSelector) {
            TrackSelectorDialog("AI Video Upscale", UpscaleMode.values().map { it.label },
                UpscaleMode.values().indexOf(currentUpscale),
                { idx -> currentUpscale = UpscaleMode.values()[idx]; showUpscaleSelector = false },
                { showUpscaleSelector = false })
        }

        // Equalizer Panel
        AnimatedVisibility(
            visible = showEqualizer,
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            EqualizerPanel(
                currentPreset = currentPreset,
                customBands = customBands,
                surroundMode = surroundMode,
                bassLevel = bassLevel,
                nightMode = nightMode,
                dialogEnhance = dialogEnhance,
                volumeNormalization = volumeNormalization,
                onPresetSelected = { preset ->
                    currentPreset = preset
                    customBands = preset.bands.copyOf()
                    dspEngine.applyEqualizerPreset(preset)
                },
                onBandChanged = { index, value ->
                    customBands[index] = value
                    currentPreset = EqualizerPreset("custom", "Custom", customBands)
                    dspEngine.applyEqualizerPreset(currentPreset)
                },
                onSurroundModeChanged = { mode ->
                    surroundMode = mode
                    dspEngine.setSurroundMode(mode)
                },
                onBassChanged = { level ->
                    bassLevel = level
                    dspEngine.setBassLevel(level)
                },
                onNightModeChanged = {
                    nightMode = it
                    dspEngine.setNightMode(it)
                },
                onDialogEnhanceChanged = {
                    dialogEnhance = it
                    dspEngine.setDialogEnhancement(it)
                },
                onVolumeNormalizationChanged = {
                    volumeNormalization = it
                    dspEngine.setVolumeNormalization(it)
                },
                onSaveCustomPreset = { showCustomSaveDialog = true },
                onDismiss = { showEqualizer = false }
            )
        }

        // Save Preset Dialog
        if (showCustomSaveDialog) {
            AlertDialog(
                onDismissRequest = { showCustomSaveDialog = false },
                title = { Text("Save Custom Preset", color = Color.White) },
                text = {
                    OutlinedTextField(
                        value = customPresetName, onValueChange = { customPresetName = it },
                        label = { Text("Preset Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CinemaSurface, unfocusedContainerColor = CinemaSurface,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                        )
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { showCustomSaveDialog = false; customPresetName = "" },
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)
                    ) { Text("Save", color = Color.Black) }
                },
                dismissButton = {
                    TextButton(onClick = { showCustomSaveDialog = false }) { Text("Cancel", color = CinemaGray) }
                },
                containerColor = CinemaSurface
            )
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
            dspEngine.release()
        }
    }
}

@Composable
fun TrackSelectorDialog(
    title: String, tracks: List<String>, selectedIndex: Int,
    onSelect: (Int) -> Unit, onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = CinemaGold, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                items(tracks.size) { index ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { onSelect(index) }
                            .padding(vertical = 12.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(tracks[index], color = if (index == selectedIndex) CinemaGold else Color.White, fontSize = 16.sp)
                        if (index == selectedIndex) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                    if (index < tracks.size - 1) Divider(color = CinemaSurfaceLight, thickness = 0.5.dp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = CinemaGray) } },
        containerColor = CinemaSurface
    )
}

@Composable
fun EqualizerPanel(
    currentPreset: EqualizerPreset, customBands: FloatArray, surroundMode: SurroundMode,
    bassLevel: Int, nightMode: Boolean, dialogEnhance: Boolean, volumeNormalization: Boolean,
    onPresetSelected: (EqualizerPreset) -> Unit, onBandChanged: (Int, Float) -> Unit,
    onSurroundModeChanged: (SurroundMode) -> Unit, onBassChanged: (Int) -> Unit,
    onNightModeChanged: (Boolean) -> Unit, onDialogEnhanceChanged: (Boolean) -> Unit,
    onVolumeNormalizationChanged: (Boolean) -> Unit, onSaveCustomPreset: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(CinemaBlack.copy(alpha = 0.98f))) {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CINEMA PRO DSP", color = CinemaGold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
                }
            }

            item {
                Text("EQUALIZER PRESETS", color = CinemaGray, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.height(280.dp).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(EqualizerPreset.ALL_PRESETS) { preset ->
                        EqualizerPresetButton(
                            presetName = preset.name, isSelected = currentPreset.id == preset.id,
                            onClick = { onPresetSelected(preset) }, modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Button(
                    onClick = onSaveCustomPreset,
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGreen),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Icon(Icons.Default.Save, null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Custom Preset", color = Color.Black)
                }
            }

            item {
                CinemaEqualizer(bands = customBands.toList(), onBandChanged = onBandChanged, isPlaying = true)
            }

            item {
                Text("SURROUND SOUND", color = CinemaGray, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
                SurroundMode.values().forEach { mode ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { onSurroundModeChanged(mode) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(mode.label, color = if (surroundMode == mode) CinemaGold else Color.White, fontSize = 16.sp)
                            Text(mode.description, color = CinemaGray, fontSize = 12.sp)
                        }
                        if (surroundMode == mode) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                }
            }

            item {
                BassControlSlider(value = bassLevel, onValueChange = onBassChanged, modifier = Modifier.padding(vertical = 8.dp))
            }

            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    ToggleOption("Night Mode", nightMode, onNightModeChanged)
                    Spacer(modifier = Modifier.height(12.dp))
                    ToggleOption("Dialog Enhancement", dialogEnhance, onDialogEnhanceChanged)
                    Spacer(modifier = Modifier.height(12.dp))
                    ToggleOption("Volume Normalization", volumeNormalization, onVolumeNormalizationChanged)
                }
            }

            item { Spacer(modifier = Modifier.height(100.dp)) }
        }
    }
}

@Composable
fun ToggleOption(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 16.sp)
        Switch(
            checked = checked, onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = CinemaGold, checkedTrackColor = CinemaGold.copy(alpha = 0.5f))
        )
    }
}

private fun formatTime(ms: Long): String {
    val seconds = (ms / 1000) % 60
    val minutes = (ms / (1000 * 60)) % 60
    val hours = ms / (1000 * 60 * 60)
    return if (hours > 0) String.format("%02d:%02d:%02d", hours, minutes, seconds)
    else String.format("%02d:%02d", minutes, seconds)
}
