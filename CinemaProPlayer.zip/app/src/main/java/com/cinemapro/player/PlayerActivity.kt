package com.cinemapro.player

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.cinemapro.player.ui.screens.CinemaProPlayerScreen
import com.cinemapro.player.ui.theme.CinemaProTheme

class PlayerActivity : ComponentActivity() {

    private var onPipChangedCallback: ((Boolean) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // NO forced orientation — player opens in portrait by default
        // User can lock/unlock rotation via the button in controls

        // See MainActivity.onCreate() for why this is required: AI 4K /
        // 3D mode forces a re-open of this same URI later, which needs a
        // persisted (not one-shot) read grant or it throws
        // FileNotFoundException inside the effects pipeline.
        intent?.data?.let { uri ->
            if (uri.scheme == "content") {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: SecurityException) {
                    // Not all providers support this — non-effects playback
                    // still works regardless.
                }
            }
        }

        val videoUri   = intent?.data?.toString() ?: ""
        val videoTitle = intent?.getStringExtra("VIDEO_TITLE") ?: ""
        val videoId    = intent?.getLongExtra("VIDEO_ID", -1L) ?: -1L

        setContent {
            CinemaProTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                    CinemaProPlayerScreen(
                        videoUri    = videoUri,
                        videoTitle  = videoTitle,
                        videoId     = videoId,
                        onBackPressed = { finish() },
                        onEnterPip  = { enterPipMode() },
                        onPipChanged = { callback -> onPipChangedCallback = callback }
                    )
                }
            }
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPip, newConfig)
        onPipChangedCallback?.invoke(isInPip)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Auto-enter PIP when home pressed during playback
        enterPipMode()
    }
}
